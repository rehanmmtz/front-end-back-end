<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item me-4">
                <a class="nav-link active" aria-current="page" href="../adminpanel">HOME</a>
            </li>
            <li class="nav-item me-4">
                <a class="nav-link" href="kategori.php">KATEGORI</a>
            </li>
            <li class="nav-item me-4">
                <a class="nav-link" href="produk.php">PRODUK</a>
            </li>
            <li class="nav-item me-4">
                <a class="nav-link" href="logout.php">LOGOUT</a>
            </li>
        </ul>
    </div>
  </div>
</nav>